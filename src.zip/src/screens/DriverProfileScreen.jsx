import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { User, Phone, Mail, Truck, AlertCircle } from 'lucide-react-native';
import { AuthContext } from '../context/AuthContext';

export default function DriverProfileScreen() {

    const { user } = React.useContext(AuthContext);

    return (

        <ScrollView className="flex-1 bg-surface px-6 pt-16">

            {/* Title */}
            <Text className="text-2xl font-outfit-bold text-secondary mb-6">
                Driver Profile
            </Text>

            {/* Profile Card */}
            <View className="bg-white rounded-3xl p-6 border border-gray-200 shadow-sm">

                {/* Driver Name */}
                <View className="flex-row items-center mb-2">
                    <User color="#2563EB" size={22} />
                    <Text className="ml-3 font-outfit text-gray-500">
                        Driver Name
                    </Text>
                </View>

                <Text className="font-outfit-bold text-lg text-secondary mb-4">
                    {user?.name || "Rahul Driver"}
                </Text>

                {/* Mobile Number */}
                <View className="flex-row items-center mb-2">
                    <Phone color="#2563EB" size={22} />
                    <Text className="ml-3 font-outfit text-gray-500">
                        Mobile Number
                    </Text>
                </View>

                <Text className="font-outfit-bold text-secondary mb-4">
                    9876543210
                </Text>

                {/* Emergency Contact */}
                <View className="flex-row items-center mb-2">
                    <AlertCircle color="#2563EB" size={22} />
                    <Text className="ml-3 font-outfit text-gray-500">
                        Emergency Contact
                    </Text>
                </View>

                <Text className="font-outfit-bold text-secondary mb-4">
                    9999999999
                </Text>

                {/* Vehicle Name */}
                <View className="flex-row items-center mb-2">
                    <Truck color="#2563EB" size={22} />
                    <Text className="ml-3 font-outfit text-gray-500">
                        Vehicle Name
                    </Text>
                </View>

                <Text className="font-outfit-bold text-secondary mb-4">
                    Swift
                </Text>

                {/* Vehicle Number */}
                <Text className="font-outfit text-gray-500">
                    Vehicle Number
                </Text>

                <Text className="font-outfit-bold text-secondary mb-4">
                    GJ01AB1234
                </Text>

                {/* Email */}
                <View className="flex-row items-center mb-2">
                    <Mail color="#2563EB" size={22} />
                    <Text className="ml-3 font-outfit text-gray-500">
                        Email
                    </Text>
                </View>

                <Text className="font-outfit-bold text-secondary">
                    {user?.email || "driver@email.com"}
                </Text>

            </View>


            {/* Trip Info */}

            <View className="mt-8">

                <Text className="text-xl font-outfit-bold text-secondary mb-4">
                    Recent Trip
                </Text>

                <View className="bg-white rounded-3xl p-6 border border-gray-200">

                    <Text className="font-outfit text-gray-500">
                        Date
                    </Text>

                    <Text className="font-outfit-bold mb-2">
                        12 March 2026
                    </Text>

                    <Text className="font-outfit text-gray-500">
                        Route
                    </Text>

                    <Text className="font-outfit-bold mb-2">
                        Ahmedabad → Vadodara
                    </Text>

                    <Text className="font-outfit text-gray-500">
                        Vehicle
                    </Text>

                    <Text className="font-outfit-bold mb-2">
                        Swift (GJ01AB1234)
                    </Text>

                    <Text className="font-outfit text-gray-500">
                        Alerts
                    </Text>

                    <Text className="font-outfit-bold">
                        2 Alerts
                    </Text>

                </View>

            </View>

        </ScrollView>
    );
}
